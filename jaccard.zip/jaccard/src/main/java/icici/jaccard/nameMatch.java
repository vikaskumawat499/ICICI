package icici.jaccard;

import java.text.DecimalFormat;
import java.util.Map;

import com.apigee.flow.execution.Action;
import com.apigee.flow.execution.ExecutionContext;
import com.apigee.flow.execution.ExecutionResult;
import com.apigee.flow.execution.spi.Execution;
import com.apigee.flow.message.MessageContext;

import info.debatty.java.stringsimilarity.Jaccard;

public class nameMatch implements Execution{
	static int stage =0;
	public static void main(String[] args) {
		String str = nameCheck("vikash","vikas",1);
		System.out.println(str);

	}
	private Map<String, String> properties; // read-only

	public nameMatch(Map<String, String> properties) {
		this.properties = properties;
	}
	public ExecutionResult execute(MessageContext messageContext, ExecutionContext executionContext) {
		try {
			String strOne = resolveVariable(this.properties.get("StringOne"), messageContext);
			String strTwo = resolveVariable(this.properties.get("StringTwo"), messageContext);
			messageContext.setVariable("StringOne", strOne);
			messageContext.setVariable("StringTwo", strTwo);
			stage =1;
			String result = nameCheck(strOne,strTwo,1);
			
			messageContext.setVariable("similarityNot", result);
			messageContext.setVariable("stage", stage);
			return ExecutionResult.SUCCESS;
		} catch (Exception ex) {
			ExecutionResult executionResult = new ExecutionResult(false, Action.ABORT);
			executionResult.setErrorResponse(ex.getMessage());
			executionResult.addErrorResponseHeader("ExceptionClass", ex.getClass().getName());
			messageContext.setVariable("stage", stage);
			messageContext.setVariable("JAVA_ERROR", ex.getMessage());
			messageContext.setVariable("JAVA_STACKTRACE", ex.getClass().getName());
			return ExecutionResult.ABORT;
		}
	}
	private String resolveVariable(String variable, MessageContext msgContext) {
	    if (variable.isEmpty())
	      return ""; 
	    if (!variable.startsWith("{") || !variable.endsWith("}"))
	      return variable; 
	    String value = msgContext.getVariable(variable.substring(1, variable.length() - 1)).toString();
	    if (value.isEmpty())
	      return variable; 
	    return value;
	  }
	public static String nameCheck(final String s1, final String S2, int precision) {
		stage =2;
		 Jaccard jacc = new Jaccard(2);
		 stage =3;
		 double similarityNot  =    1- jacc.similarity(s1, S2);
		 stage =4;
		StringBuilder sb = new StringBuilder("#");
		if (precision > 0) {
		sb.append ('.');
		for (int i = 0; i < precision; i++) {
		     sb.append ('#') ;
		}
		}
		DecimalFormat df = new DecimalFormat (sb.toString());
		return df.format (similarityNot);
		}
}
