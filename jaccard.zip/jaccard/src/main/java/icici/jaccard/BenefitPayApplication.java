package icici.jaccard;

import java.util.Map;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import com.apigee.flow.execution.Action;
import com.apigee.flow.execution.ExecutionContext;
import com.apigee.flow.execution.ExecutionResult;
import com.apigee.flow.execution.spi.Execution;
import com.apigee.flow.message.MessageContext;

public class BenefitPayApplication implements Execution {

	public static void main(String[] args) throws Exception {
		String str ="10314404314910314404314910314404";
		String str1 ="7DAAE6AF1F940EB2B1ADE14205E18C455EA5AECF7B3A07AFB5835F84C78C65259F5BD3EBB329DFCC26900EC1BE0356E36D867C73B23BC841CADBA77277BD4520832B37FA8501F8C11AFAEAB74977D341120E4B73AAFA7F8DCED1617B9D48CEE52ED58DC8B2EEEF9858E229F2C1ADD69E6EC0B94EA9D87AAF7FC0FD434350629813587D20217A956992CF7D9944F434538132E275B296734B8562EB403EF09BC367505E86D8622525AB88C1FD77E17053526F608AF5A27658E4FE3A2D6BE0081CCB1AAC705F4F374DA2A6FFC5483476E6FADB151671C27251CA4866B0404B319070A0F7ED72AF093D356AF3B7A66C0F3025C0AB94EADED3EC12755E8EFF3F9ED439E85FD901AA8E38CFF0FCD82483F9B204EFE14CEC0559FDCA1A9263017A6D2959C75B06F99426F8B01D101E23B64D49AF7060430D2FD273C9CF5F914145EC7B33EC1BE2159259A00927AF4571CB996C80B680F2D3759E45C0606A2E7D3C7C5F";
		String result= decryptAES(str, str1);
		System.out.println(result);
	}
	
	private Map<String, String> properties; // read-only

	public BenefitPayApplication(Map<String, String> properties) {
		this.properties = properties;
	}
	
	public ExecutionResult execute(MessageContext messageContext, ExecutionContext arg1) {
		try {
			String strOne = resolveVariable(this.properties.get("StringOne"), messageContext);
			String strTwo = resolveVariable(this.properties.get("StringTwo"), messageContext);
			String result= decryptAES(strOne, strTwo);
			messageContext.setVariable("result", result);
			return ExecutionResult.SUCCESS;
		}
		catch (Exception ex) {
			ExecutionResult executionResult = new ExecutionResult(false, Action.ABORT);
			executionResult.setErrorResponse(ex.getMessage());
			executionResult.addErrorResponseHeader("ExceptionClass", ex.getClass().getName());
			messageContext.setVariable("JAVA_ERROR", ex.getMessage());
			messageContext.setVariable("JAVA_STACKTRACE", ex.getClass().getName());
			return ExecutionResult.ABORT;
		}
	}
	private String resolveVariable(String variable, MessageContext msgContext) {
	    if (variable.isEmpty())
	      return ""; 
	    if (!variable.startsWith("{") || !variable.endsWith("}"))
	      return variable; 
	    String value = msgContext.getVariable(variable.substring(1, variable.length() - 1)).toString();
	    if (value.isEmpty())
	      return variable; 
	    return value;
	  }
	private static String decryptAES(String key, String encryptedString) throws Exception {
		String AES_IV = "PGKEYENCDECIVSPC";
		SecretKeySpec skeySpec = null;
		IvParameterSpec ivspec = null;
		Cipher cipher = null;
		byte[] textDecrypted = null;
		try {
			byte[] b = decodeHexString(encryptedString);
			skeySpec = new SecretKeySpec(key.getBytes("UTF-8"), "AES");
			ivspec = new IvParameterSpec(AES_IV.getBytes("UTF-8"));
			cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			cipher.init(Cipher.DECRYPT_MODE, skeySpec, ivspec);
			textDecrypted = cipher.doFinal(b);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			skeySpec = null;
			ivspec = null;
			cipher = null;
		}
		return (new String(textDecrypted));
	}

	public static byte[] decodeHexString(String hexString) {
		if (hexString.length() % 2 == 1) {
			throw new IllegalArgumentException("Invalid hexadecimal String supplied.");
		}

		byte[] bytes = new byte[hexString.length() / 2];
		for (int i = 0; i < hexString.length(); i += 2) {
			bytes[i / 2] = hexToByte(hexString.substring(i, i + 2));
		}
		return bytes;
	}

	public static byte hexToByte(String hexString) {
		int firstDigit = toDigit(hexString.charAt(0));
		int secondDigit = toDigit(hexString.charAt(1));
		return (byte) ((firstDigit << 4) + secondDigit);
	}

	private static int toDigit(char hexChar) {
		int digit = Character.digit(hexChar, 16);
		if (digit == -1) {
			throw new IllegalArgumentException("Invalid Hexadecimal Character: " + hexChar);
		}
		return digit;
	}
}

